import java.util.ArrayList;
public class MyArrayListArray
{
public static void main(String ar[])
{
	ArrayList<String> arr1=new ArrayList<String>();
	arr1.add("first");
	arr1.add("second");
arr1.add("Third");
arr1.add("Random");	
System.out.println("Actual ArrayList:"+arr1);
String[]strArr=new String[arr1.size()];
arr1.toArray(strArr);
System.out.println("Created Array content:");
for(String str:strArr)
{
	System.out.println(str);
}
for(String str:arr1)
{
	System.out.println(str);
}

}
}