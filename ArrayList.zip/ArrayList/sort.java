import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class sort
{
public static void main(String ar[])
{
	ArrayList<String> list=new ArrayList<>();
	list.add("Ram");
	list.add("Jhon");
	list.add("Crish");
	list.add("Tom");
	Collections.sort(list);
	System.out.println("Sorted list entries: "+list);
}

}