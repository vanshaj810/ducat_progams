import java.util.ArrayList;
import java.util.List;

public class SubListExample
{
public static void main(String ar[])
{
	
	ArrayList<String> al=new ArrayList<String>();
	//Adding of element in ArrayList
	al.add("Pandya");
	al.add("Rohit");
	al.add("Dhoni");
	al.add("rayana");
	al.add("virat");
	al.add("Yovraj");
	System.out.println("Original ArrayList content: "+al);
	//SubList to ArrayList
	ArrayList<String> al2=new ArrayList<String>(al.subList(1,4));
    System.out.println("SubList stored in ArrayList: "+al2);
	//SubList to List
	List<String> list=al.subList(1,4);
    System.out.println("SubList stored in List:"+list);
	}
	}