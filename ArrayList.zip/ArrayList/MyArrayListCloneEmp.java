import java.util.*;
import java.util.Collections;
public class MyArrayListCloneEmp
{
public static void main(String ar[])
{
	ArrayList<Emp> list=new ArrayList<Emp>();
	list.add(new Emp(1001));
	list.add(new Emp(1002));
	list.add(new Emp(1003));
	list.add(new Emp(1004));
	list.add(new Emp(1005));
	System.out.println("Actual List:");
	for(Emp str:list)
	{
		System.out.println(str.x);
	}
		ArrayList<Emp>copy=(ArrayList<Emp>)list.clone();
		System.out.println("Cloned ArrayList:");
		
		for(Emp str:copy)
		{
			System.out.println(str.x);
		}	
		Emp e1=list.get(0);
			Emp e2=list.get(0);
			//copy.set(0,(Emp)list.get(0).clone())//deep clone
			if(e1==e2)
			{
			System.out.println("Shallow");
			}
			if(list !=copy)
			{
			System.out.println("Clone");
			}
		}
}
	class Emp
	{
		int x;
		Emp(int x)
		{
			this.x=x;
		}
	}