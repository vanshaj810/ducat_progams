import java.util.ArrayList;
import java.io.*;
public class ArrayListSerialization
{
public static void main(String ar[])
{
	ArrayList<String> al=new ArrayList<String>();
	al.add("Hello");
	al.add("Hi");
	al.add("Howdy");
	try
	{
		FileOutputStream fos=new FileOutputStream("myfile.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(al);
		oos.close();
		fos.close();
		System.out.println("after deserilization");
		FileInputStream fin=new FileInputStream("myfile.txt");
		ObjectInputStream oin=new ObjectInputStream(fin);
		ArrayList aL1=(ArrayList)oin.readObject();
		System.out.println("length of aL1: "+aL1.size());
		System.out.println(aL1);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
}