import java.util.*;
//import java.util.arrayliststIterator;

public class TrimExample
{
public static void main(String ar[])
{
	
	Vector<Integer> arraylist=new Vector<Integer>(50);
	
	arraylist.add(1);
	arraylist.add(2);
	arraylist.add(3);
	arraylist.add(4);
	arraylist.add(5);
	arraylist.add(6);
	System.out.println(arraylist.capacity());
	System.out.println(arraylist.size());
	arraylist.trimToSize();
	System.out.println(arraylist.capacity());
	}
	}