import java.util.*;
public class ArrayListToArray
{
public static void main(String ar[])
{
ArrayList<String> arlist=new ArrayList<String>();
arlist.add("String1");
arlist.add("String2");
arlist.add("String3");
arlist.add("String4");
//ArrayList to Array Conversion itself
String array[]=new String[arlist.size()];
for(int j=0;j<arlist.size();j++)
{
array[j]=arlist.get(j);
}
//Display Array element
for(String k:array)
{
System.out.println(k);
}
//pre define
Object g[] = arlist.toArray();
for(Object k:g)
{
System.out.println(k);
}
}
}