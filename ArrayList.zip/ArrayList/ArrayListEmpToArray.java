import java.util.ArrayList;
public class ArrayListEmpToArray
{
public static void main(String ar[])
{
	ArrayList<Emp> list=new ArrayList<Emp>();
	list.add(new Emp(1001,"lalu"));
	list.add(new Emp(1002,"rabari"));
	list.add(new Emp(1003,"meesa"));
	list.add(new Emp(1004,"tej"));
	Object o[]=list.toArray();
	for(int i=0;i<o.length;i++)
	{
	Emp z=(Emp)o[i];
	//System.out.print(((Emp)o[i]).id+" ");
	System.out.print(z.id);
	System.out.print(" "+z.name);
	System.out.println("");
	}
	System.out.println("");
	for(Emp z:list)
	{
	System.out.print(z.id);
	System.out.print(""+z.name);
	System.out.println("");
	}
}
}
  class Emp
   {
	 int id;
	 String name;
	Emp(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
   }