import java.util.*;
class ArrayListDemo3
{
public static void main(String ar[])
{
ArrayList<ArrayList> al=new ArrayList<ArrayList>();
ArrayList<String> als=new ArrayList<String>();
System.out.println("initial size of als: "+al.size());
als.add("a");
als.add("b");
als.add("c");
al.add(als);
al.add(al);
System.out.println("size of al: "+al.size());
System.out.println("size of als: "+als.size());
System.out.println("al: "+al);
System.out.println("als: "+als);
}
}
