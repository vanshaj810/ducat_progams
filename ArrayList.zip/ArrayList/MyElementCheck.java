import java.util.ArrayList;
import java.util.List;
public class MyElementCheck
{
public static void main(String ar[])
{
	
	ArrayList<String> list=new ArrayList<String>();
	list.add("First");
	list.add("Second");
	list.add("Third");
	list.add("Random");
	List<String> l=new ArrayList<String>();
	l.add("Second");
	l.add("Random");
	System.out.println("Does  ArrayList contains all list element?:"+list.containsAll(l));
	l.add("One");
	System.out.println("Does  ArrayList contains all list element?:"+list.containsAll(l));
	}
	}