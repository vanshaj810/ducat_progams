import java.util.ArrayList;
class ArrayListDemo
{
public static void main(String ar[])
{
ArrayList<String> al=new ArrayList<String>();  //generic <>
//ArrayList al=new ArrayList();
System.out.println("Initial Size of ArrayList: "+al.size());
al.add("a");
al.add("b");
al.add("a");
al.add("d");
al.add(String.valueOf(new Integer(10)));
System.out.println("Size of ArrayList: "+al.size());
System.out.println(al);
al.remove(2);
System.out.println("After removing Size of ArrayList: "+al.size());
System.out.println(al);
}
}