import java.util.*;
public class ArrayToArrayList
{
public static void main(String ar[])
{
//Array Declaration and initialization
String citynames[]={"Agra","Noida","Chandigarh","Delhi"};
List<String> l=Arrays.asList(citynames);
//Array to ArrayList Conversion
ArrayList<String>citylist=new ArrayList<String>(l);
citylist.add("Patna");
citylist.add("Gorakhpur");
for(String str: citylist)
{
	System.out.println(str);
}
}
}