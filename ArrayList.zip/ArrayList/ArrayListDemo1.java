import java.util.*;
class ArrayListDemo1
{
	public static void main(String ar[])
	{
		ArrayList<Integer> al=new ArrayList<Integer>();
		//ArrayList al=new ArrayList();
		int x[]={1,-1,2,-2,3,-3,4,-4};
		for(int i:x)
			al.add(i);
		System.out.println(al);
		Iterator<Integer> i=al.iterator();
		while(i.hasNext())
		{
			Integer z=i.next();
			if(z.intValue()<0)
				i.remove();
		}
		System.out.println("After removing -ve value");
		System.out.println(al);
	}
}