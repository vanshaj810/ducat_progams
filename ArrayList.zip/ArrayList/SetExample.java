import java.util.ArrayList;
//import java.util.ListIterator;

public class SetExample
{
public static void main(String ar[])
{
	
	ArrayList<Integer> li=new ArrayList<Integer>();
	
	li.add(1);
	li.add(2);
	li.add(3);
	li.add(4);
	System.out.println("ArrayList before update:"+li);
	li.set(0,11);
	li.set(1,22);
	li.set(2,33);
	li.set(3,44);
	System.out.println("ArrayList after update:"+li);
	}
	}