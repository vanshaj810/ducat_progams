import java.util.ArrayList;
import java.util.Iterator;
public class ArrayListEmp
{
public static void main(String ar[])
{
	ArrayList<Emp> list=new ArrayList<Emp>();
	list.add(new Emp(101,"modi"));
	list.add(new Emp(102,"shah"));
	list.add(new Emp(103,"yogi"));
	list.add(new Emp(104,"adwani"));
	Iterator<Emp> i=list.iterator();
	while(i.hasNext())  
	{
	Emp z=i.next();   
	System.out.print(z.id);
	System.out.print(" "+z.name);
	System.out.println("");
	if(z.id==104)
	{
		System.out.println(z.name +" is removed....");
		i.remove();
	}
	}
	System.out.println("After removing element");
	i=list.iterator();
	while(i.hasNext())
	{
	Emp z=i.next();
	System.out.print(z.id);
	System.out.print(" "+z.name);
	System.out.println("");
	}
}
}
  class Emp
   {
	 int id;
	 String name;
	Emp(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
}