import java.util.*;
public class SortingArrayList
{
public static void main(String ar[])
{
	
	ArrayList<String>listofountries =new ArrayList<String>();
	//Adding of element in ArrayList
	listofountries.add("India");
	listofountries.add("Us");
	listofountries.add("China");
	listofountries.add("Denmark");
	listofountries.add("China");
//Unsorted list
	System.out.println("Before Sorting:");
	for(String counter:listofountries)
	{
		System.out.println(counter);
	}
	//Sort Statement
	Collections.sort(listofountries);
	//sort list
	System.out.println("after sorting:");
	for(String counter:listofountries)
	{
		System.out.println(counter);
	}
}
}