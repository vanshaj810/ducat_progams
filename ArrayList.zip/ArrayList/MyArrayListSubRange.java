import java.util.ArrayList;
import java.util.List;
public class MyArrayListSubRange
{
public static void main(String ar[])
{
	ArrayList<String> list=new ArrayList<String>();
	list.add("First");
	list.add("Second");
	list.add("Third");
	list.add("Random");
	list.add("Click");
	System.out.println("Actual ArrayList:"+list);
	List<String> arrl=list.subList(2,4);
	System.out.println(" Sub arrl:"+arrl);
	}
	}