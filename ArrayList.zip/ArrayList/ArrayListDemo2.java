//to convert ArrayList into array
import java.util.*;
 class  ArrayListDemo2 
{
	public static void main(String ar[])
	{
	ArrayList<Number> al=new ArrayList<>();
	int x[]={1,-1,2,-2,3,-3,4,-4};
	for(int i=0;i<x.length;i++)
	{
	al.add(x[i]);
	}
	al.add(2.5);
	Object o[]=al.toArray();
	for(int i=0;i<o.length;i++)
	{	
	Number z=(Number)o[i];
	System.out.print(z.intValue()+" ");
	}
	System.out.println(" ");
	//forEach loop (advance loop)
	for(Number i:al)
	System.out.print(i+" ");
	}
	}