import java.util.ArrayList;
public class MyArrayListclone
{
public static void main(String ar[])
{
	ArrayList<String> arr1=new ArrayList<String>();
	//adding elements to the end.
	arr1.add("first");
	arr1.add("second");
arr1.add("Third");
arr1.add("Random");	
System.out.println("Actual ArrayList:	"+arr1);
ArrayList<String>copy=(ArrayList<String>)arr1.clone();
System.out.println("cloned ArrayList:  "+copy);
if(arr1.get(0)==copy.get(0))
{
System.out.println("Shallow");
}
if(arr1!=copy)
{
	System.out.println("clone");
}
}
}
