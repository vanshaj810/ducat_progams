import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class MyItrRemoveElement
{
public static void main(String ar[])
{
	String removeElem ="Perl";
	ArrayList<String> mylist=new ArrayList<String>();
	mylist.add("Java");
	mylist.add("Unix");
	mylist.add("Oracle");
	mylist.add("C++");
	mylist.add("Perl");
	mylist.add("Perl");
	mylist.add("Perl");
	
	System.out.println("Before remove:");
	System.out.println(mylist);
	Iterator<String>itr=mylist.iterator();
	while(itr.hasNext())
	{
	if(removeElem.equals(itr.next()))
{
itr.remove();
}
}	
	System.out.println("After remove:");
	System.out.println("mylist");
	}
	}